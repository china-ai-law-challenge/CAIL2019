DATAFILE=../data/data.json
PREDFILE=../result/result.json

python main.py \
--infile=${DATAFILE} \
--outfile=${PREDFILE} \
