import os
import json

os.system("g++ work.cpp -o work -O2")
os.system("./work")
